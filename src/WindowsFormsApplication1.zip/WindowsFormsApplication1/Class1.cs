﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Class1
    {
        Diagram mDiagram;
        Random mRandom;
        IList<Node> nodeList;

        public Class1(int numOfPoints)
        {
            mDiagram = new Diagram();
            mRandom = new Random();


            mDiagram.Clear();
            Node[] nodes = new Node[numOfPoints];
            for (int i = 0; i < numOfPoints; i++)
            {
                Node n = new SpotNode(Color.Black);
                mDiagram.AddNode(n);
                nodes[i] = n;
                for (int j = 0; j < i; j++)
                {
                    nodes[j].AddChild(nodes[i]);
                }
                //if (i > 0) nodes[i - 1].AddChild(nodes[i]);
            }

            mDiagram.Arrange();

            foreach (Node n in nodes)
            {
                Console.Out.WriteLine(n.X.ToString() + " " + n.Y.ToString());
            }

        }
    }
}
