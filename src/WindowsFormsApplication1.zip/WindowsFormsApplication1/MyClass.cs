﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class MyClass
    {
        Diagram mDiagram;
        Random mRandom;

        public MyClass()
        {
            mDiagram = new Diagram();
            mRandom = new Random();
        }
    }
}
