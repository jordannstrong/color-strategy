﻿using System;
using System.Windows.Forms;
using WindowsFormsApplication1;

/// <summary>
/// This utility is provided free of charge by Brad Smith at http://www.brad-smith.info/
/// </summary>

namespace ForceDirected
{
    static class Program {
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(String[] args) {
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Demo(5));
            Class1 c = new Class1(Int32.Parse((args[0])));
		}
	}
}
